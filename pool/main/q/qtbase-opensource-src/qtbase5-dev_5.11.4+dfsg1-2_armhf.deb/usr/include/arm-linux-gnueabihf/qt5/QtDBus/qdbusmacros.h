#ifndef DEPRECATED_HEADER_QtDBus_qdbusmacros_h
#define DEPRECATED_HEADER_QtDBus_qdbusmacros_h
#if defined(__GNUC__)
#  warning Header <QtDBus/qdbusmacros.h> is deprecated. Please include <QtDbus/qtdbusglobal.h> instead.
#elif defined(_MSC_VER)
#  pragma message ("Header <QtDBus/qdbusmacros.h> is deprecated. Please include <QtDbus/qtdbusglobal.h> instead.")
#endif
#include <QtDbus/qtdbusglobal.h>
#if 0
#pragma qt_no_master_include
#endif
#endif
